SUBIR A GITHUB
1. Sube TrayectoriaTiros-v2-Nueva.zip al repositorio.
2. Crea .github/workflows/build.yml y usa el workflow incluido en el ZIP original.
3. Ejecuta Actions > Build APK > Run workflow.
