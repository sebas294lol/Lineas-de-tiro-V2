plugins { id("com.android.application") }

android {
    namespace = "com.trayectoriadetiros"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.trayectoriadetiros"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
