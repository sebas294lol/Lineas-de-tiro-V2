package com.trayectoriadetiros;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.Random;

public class MainActivity extends Activity {
    LinearLayout root; PitchView pitch; Random rng = new Random();
    int screen = 0, difficulty = 0, goals = 0, shots = 0, saves = 0;
    int curve = 0, power = 6; boolean challenge = false;

    @Override public void onCreate(Bundle b) { super.onCreate(b); showMenu(); }
    TextView title(String s, int size) { TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); t.setGravity(Gravity.CENTER); t.setPadding(12,16,12,16); return t; }
    Button btn(String s) { Button b=new Button(this); b.setText(s); b.setTextSize(17); b.setAllCaps(false); b.setTextColor(Color.WHITE); GradientDrawable g=new GradientDrawable(); g.setColor(Color.rgb(35,35,35)); g.setCornerRadius(24); b.setBackground(g); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,58); p.setMargins(24,8,24,8); b.setLayoutParams(p); return b; }
    void base() { root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(12,12,12,12); root.setBackgroundColor(Color.rgb(12,12,12)); setContentView(root); }

    void showMenu() {
        screen=0; base(); root.addView(title("⚽ TRAYECTORIA DE TIROS",28)); root.addView(title("Practica tus disparos",16));
        Button n=btn("🎯 Normal"); n.setOnClickListener(v->showPractice(false)); root.addView(n);
        Button r=btn("🏆 Retos"); r.setOnClickListener(v->showPractice(true)); root.addView(r);
        Button k=btn("🧤 Modo Portero"); k.setOnClickListener(v->showKeeper()); root.addView(k);
    }
    void showPractice(boolean ch) {
        screen=1; challenge=ch; goals=0; base(); root.addView(title(ch?"🏆 RETOS":"🎯 NORMAL",25));
        pitch=new PitchView(); root.addView(pitch,new LinearLayout.LayoutParams(-1,0,1));
        TextView info=title("Toca el arco para elegir dónde tirar",15); root.addView(info);
        root.addView(title("Curva: 0",14));
        SeekBar cb=new SeekBar(this); cb.setMax(60); cb.setProgress(30); cb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){curve=p-30; pitch.curve=curve; pitch.invalidate();} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}}); root.addView(cb);
        root.addView(title("Potencia: 6",14));
        SeekBar pb=new SeekBar(this); pb.setMax(9); pb.setProgress(5); pb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){power=p+1; pitch.power=power; pitch.invalidate();} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){}}); root.addView(pb);
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); Button shoot=btn("⚽ DISPARAR"); Button back=btn("↩ Menú"); row.addView(shoot,new LinearLayout.LayoutParams(0,58,1)); row.addView(back,new LinearLayout.LayoutParams(0,58,1)); root.addView(row);
        shoot.setOnClickListener(v->{pitch.shoot(false);}); back.setOnClickListener(v->showMenu());
    }
    void showKeeper() {
        screen=2; shots=0; saves=0; goals=0; base(); root.addView(title("🧤 MODO PORTERO",25));
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        String[] ds={"Fácil","Medio","Difícil"}; for(int i=0;i<3;i++){ final int d=i; Button b=btn(ds[i]); b.setTextSize(14); b.setOnClickListener(v->{difficulty=d; pitch.invalidate();}); row.addView(b,new LinearLayout.LayoutParams(0,58,1)); }
        root.addView(row); pitch=new PitchView(); root.addView(pitch,new LinearLayout.LayoutParams(-1,0,1));
        Button shoot=btn("⚽ LANZAR TIRO"); Button back=btn("↩ Menú"); root.addView(shoot); root.addView(back);
        shoot.setOnClickListener(v->pitch.shoot(true)); back.setOnClickListener(v->showMenu());
        root.addView(title("Tiros: 0   Atajadas: 0   Goles: 0",14));
    }
    void updateKeeperText(){ if(root==null)return; for(int i=0;i<root.getChildCount();i++){View v=root.getChildAt(i); if(v instanceof TextView){TextView t=(TextView)v; if(t.getText().toString().startsWith("Tiros:")) t.setText("Tiros: "+shots+"   Atajadas: "+saves+"   Goles: "+goals);}} }

    class PitchView extends View {
        Paint p=new Paint(3); float tx,ty,bx,by; float startX,startY; int curve=0,power=6; boolean moving=false, keeperShot=false; long start;
        PitchView(){super(MainActivity.this); p.setStrokeWidth(4); setBackgroundColor(Color.rgb(25,120,55));}
        protected void onDraw(Canvas c){ super.onDraw(c); float w=getWidth(),h=getHeight(); p.setStyle(Paint.Style.STROKE);p.setColor(Color.WHITE);p.setStrokeWidth(3); c.drawRect(8,8,w-8,h-8,p); c.drawLine(w*.5f,8,w*.5f,h-8,p); c.drawCircle(w*.5f,h*.5f,55,p); c.drawRect(w-115,h*.25f,w-8,h*.75f,p); c.drawRect(w-55,h*.38f,w-8,h*.62f,p);
            if(tx==0){tx=w-35;ty=h*.5f;} p.setStyle(Paint.Style.FILL);p.setColor(Color.YELLOW);c.drawCircle(tx,ty,10,p);
            if(!moving){bx=55;by=h*.5f;}
            if(moving){ drawTrajectory(c,w,h); }
            drawBall(c,bx,by); drawPlayer(c,48,h*.5f);
            if(keeperShot) drawKeeper(c,w-45,h*.5f);
        }
        void drawBall(Canvas c,float x,float y){p.setColor(Color.WHITE);c.drawCircle(x,y,10,p);p.setColor(Color.BLACK);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawCircle(x,y,9,p);p.setStyle(Paint.Style.FILL);}
        void drawPlayer(Canvas c,float x,float y){ // small pixel-style player in a generic white kit
            p.setColor(Color.rgb(245,205,170)); c.drawRect(x-6,y-30,x+6,y-18,p); p.setColor(Color.WHITE); c.drawRect(x-9,y-18,x+9,y+8,p); c.drawRect(x-14,y-14,x-9,y+2,p); c.drawRect(x+9,y-14,x+14,y+2,p); p.setColor(Color.rgb(35,35,35)); c.drawRect(x-8,y+8,x-1,y+25,p); c.drawRect(x+1,y+8,x+8,y+25,p); p.setColor(Color.WHITE); c.drawRect(x-9,y+24,x-1,y+28,p); c.drawRect(x+1,y+24,x+9,y+28,p); }
        void drawKeeper(Canvas c,float x,float y){p.setColor(Color.rgb(245,205,170));c.drawCircle(x,y-22,6,p);p.setColor(Color.rgb(40,120,220));c.drawRect(x-8,y-16,x+8,y+7,p);c.drawRect(x-16,y-13,x-8,y-7,p);c.drawRect(x+8,y-13,x+16,y-7,p);}
        void drawTrajectory(Canvas c,float w,float h){p.setColor(Color.YELLOW);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);Path path=new Path();path.moveTo(startX,startY);for(int i=1;i<=30;i++){float q=i/30f;float x=startX+(tx-startX)*q;float y=startY+(ty-startY)*q + (float)(curve*2.2f*Math.sin(Math.PI*q)); path.lineTo(x,y);}c.drawPath(path,p);p.setStyle(Paint.Style.FILL);}
        public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN && !moving){tx=Math.max(getWidth()*.68f,Math.min(getWidth()-12,e.getX()));ty=Math.max(15,Math.min(getHeight()-15,e.getY()));invalidate();return true;}return true;}
        void shoot(boolean ks){ if(moving)return; keeperShot=ks; startX=55;startY=getHeight()*.5f; if(ks){int spread=difficulty==0?35:(difficulty==1?110:190);tx=getWidth()-20;ty=getHeight()*.5f+(rng.nextFloat()-.5f)*spread;curve=(rng.nextInt(2)==0?-1:1)*(difficulty==0?8:(difficulty==1?18:28));power=difficulty==0?4:(difficulty==1?7:9);shots++;} moving=true;start=System.currentTimeMillis();postInvalidateOnAnimation();}
        void resolve(){ if(keeperShot){double base=difficulty==0?.72:difficulty==1?.50:.30; double mod=Math.abs(ty-getHeight()*.5f)/(getHeight()*.5f)*.18; boolean save=rng.nextDouble() < base-mod; if(save)saves++;else goals++; updateKeeperText();} else if(challenge){goals++; Toast.makeText(MainActivity.this,"Reto: "+goals+" / 3",Toast.LENGTH_SHORT).show(); if(goals>=3) Toast.makeText(MainActivity.this,"🏆 Reto completado",Toast.LENGTH_LONG).show();}}
        public void computeScroll(){if(!moving)return;float t=(System.currentTimeMillis()-start)/(850f-(power*45f)); if(t>=1){bx=tx;by=ty;moving=false;resolve();invalidate();return;} bx=startX+(tx-startX)*t; by=startY+(ty-startY)*t+(float)(curve*2.2f*Math.sin(Math.PI*t)); postInvalidateOnAnimation();}
    }
}
