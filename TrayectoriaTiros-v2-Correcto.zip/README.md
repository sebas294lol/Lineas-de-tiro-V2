# Trayectoria de Tiros v2

Proyecto Android ligero para practicar trayectorias de tiros de fútbol.

Incluye Normal, Retos y Modo Portero, con curva, potencia, objetivo táctil y jugador pixelado.

Para GitHub: sube el CONTENIDO de esta carpeta al repositorio, no el ZIP como archivo. `settings.gradle.kts` debe quedar en la raíz del repositorio.
